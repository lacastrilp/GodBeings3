package BeingsOfTheEarth;

public interface EarthBeinInt {
    public void born ();
    public void die ();
    public void grow ();
    public void respawn ();
}
