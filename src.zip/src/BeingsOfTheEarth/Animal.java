package BeingsOfTheEarth;

import GodCreator.LivingBeings;

public class Animal extends LivingBeings implements EarthBeinInt {
    @Override
    public void born() {
        System.out.println("The animal is being born");

    }

    @Override
    public void die() {
        System.out.println("The animal is dying");
    }

    @Override
    public void grow() {
        System.out.println("The animal is growing");

    }

    @Override
    public void respawn() {
        System.out.println("The animal is respawning");

    }

    @Override
    public void reproduce() {
        System.out.println("The animal is reproducing");
    }
}
