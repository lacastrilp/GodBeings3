package GodCreator;

import BeingsOfTheEarth.Animal;
import BeingsOfTheEarth.Human;
import SkyBeings.Angel;
import SkyBeings.Bird;

public class LivingBeingCreator implements Creator {
    @Override
    public LivingBeings createLivingBeings(String type) {
        if (type.equalsIgnoreCase("human")) {
            return new BeingsOfTheEarth.Human();
        } else if (type.equalsIgnoreCase("animal")) {
            return new BeingsOfTheEarth.Animal();
        } else if (type.equalsIgnoreCase("celestial")) {
            return new SkyBeings.Angel();
        } else if (type.equalsIgnoreCase("bird")) {
            return new SkyBeings.Bird();
        } else {
            throw new IllegalArgumentException("Tipo de ser vivo desconocido: " + type);
        }
    }

    public static void main(String[] args) {
        LivingBeingCreator creatorOfLivingBeings = new LivingBeingCreator();


        Human Human = (Human) creatorOfLivingBeings.createLivingBeings("human");
        Human.born();
        Human.grow();
        Human.reproduce();
        Human.respawn();
        Human.fly();
        Human.changeDimensionChange();
        Human.die();

        Animal Animal = (Animal) creatorOfLivingBeings.createLivingBeings("Animal");
        Animal.born();
        Animal.grow();
        Animal.reproduce();
        Animal.die();
        Animal.respawn();

        Angel Angel = (Angel) creatorOfLivingBeings.createLivingBeings("celestial");
        Angel.born();
        Angel.grow();
        Angel.reproduce();
        Angel.respawn();
        Angel.fly();
        Angel.changeDimensionChange();
        Angel.die();


        Bird Bird = (Bird) creatorOfLivingBeings.createLivingBeings("bird");
        Bird.born();
        Bird.grow();
        Bird.reproduce();
        Bird.respawn();
        Bird.fly();
        Bird.changeDimensionChange();
        Bird.die();


    }

}
