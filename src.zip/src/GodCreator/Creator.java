package GodCreator;

public interface Creator {
    public LivingBeings createLivingBeings(String type);

}
