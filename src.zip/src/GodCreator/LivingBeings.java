package GodCreator;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public abstract class LivingBeings {

    public abstract void born ();
    public abstract void die ();
    public abstract void grow ();
    public abstract void respawn();
    public abstract void reproduce ();



}