package SkyBeings;

import BeingsOfTheEarth.EarthBeinInt;
import GodCreator.LivingBeings;

public class Angel extends LivingBeings implements SkyBeingInt, EarthBeinInt {

    @Override
    public void born() {
        System.out.println("The Angel being is being born");

    }

    @Override
    public void die() {
        System.out.println("The Angel being is dying");

    }

    @Override
    public void grow() {
        System.out.println("The Angel being is growing");

    }

    @Override
    public void respawn() {
        System.out.println("The Angel being is respawning");

    }

    @Override
    public void reproduce() {
        System.out.println("The Angel being is reproducing");
    }

    @Override
    public void fly() {
        System.out.println("The Angel being is flying");

    }

    @Override
    public void changeDimensionChange() {
        System.out.println("The Angel being is changing dimensions");

    }
}
