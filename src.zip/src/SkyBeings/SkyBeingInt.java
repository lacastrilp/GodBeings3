package SkyBeings;

public interface SkyBeingInt {
    public void fly();
    public void changeDimensionChange();
}
