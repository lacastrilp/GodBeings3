package SkyBeings;

import BeingsOfTheEarth.EarthBeinInt;
import GodCreator.LivingBeings;

public class Bird extends LivingBeings implements SkyBeingInt, EarthBeinInt {
    @Override
    public void born() {
        System.out.println("The bird being is being born");

    }

    @Override
    public void die() {
        System.out.println("The bird being is dying");
    }

    @Override
    public void grow() {
        System.out.println("The bird being is growing");

    }

    @Override
    public void respawn() {
        System.out.println("The bird being is respawning");

    }

    @Override
    public void reproduce() {
        System.out.println("The bird being is reproducing");
    }

    @Override
    public void fly() {
        System.out.println("The bird being is flying");

    }

    @Override
    public void changeDimensionChange() {
        System.out.println("The bird being is changing dimensions");

    }


}
